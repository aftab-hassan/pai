  gcc -g test.c -Wall ./libpaillier.a ./libgmp.a -o aftab
./aftab
